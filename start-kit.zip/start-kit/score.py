import findfile
import numpy as np

from omnigenome import RegressionMetric, ClassificationMetric

prediction_path = 'predictions'
ground_truth_path = 'ground_truth'

def inverse_root_mean_squared_error(y_true, y_pred):
    mse = RegressionMetric().mean_squared_error(y_true, y_pred)
    return {"inverse_root_mean_squared_error": 1/(np.sqrt(mse["mean_squared_error"])+1)}


def score(output_dir, reference_dir, score_dir):
    task2metric = {
        'RNA-mRNA': inverse_root_mean_squared_error,
        'RNA-SNMD': ClassificationMetric(average='macro').roc_auc_score,
        'RNA-SNMR': ClassificationMetric(average='macro').f1_score,
        'RNA-SSP-Archive2': ClassificationMetric(average='macro').f1_score,
        'RNA-SSP-rnastralign': ClassificationMetric(average='macro').f1_score,
        'RNA-SSP-bpRNA': ClassificationMetric(average='macro').f1_score,
        'DNA-Ineffective-Antibiotic': ClassificationMetric(average='macro').f1_score
    }

    metrics = ["inverse_root_mean_squared_error",
               "roc_auc_score",
               "f1_score",
               "f1_score",
               "f1_score",
               "f1_score",
               "f1_score"]

    task2weight = {
        'RNA-mRNA': 1,
        'RNA-SNMD': 1,
        'RNA-SNMR': 1,
        'RNA-SSP-Archive2': 2/3,
        'RNA-SSP-rnastralign': 2/3,
        'RNA-SSP-bpRNA': 2/3,
        'DNA-Ineffective-Antibiotic': 1
    }

    weighted_score_sum = 0

    for i, task in enumerate(task2metric.keys()):
        test_pred = findfile.find_cwd_file([prediction_path, task, 'test.npy'])
        test_gt = findfile.find_cwd_file([ground_truth_path, task, 'test.npy'])
        prediction = np.load(test_pred, allow_pickle=True).item()['pred'].reshape(-1)
        ground_truth = np.load(test_gt, allow_pickle=True).item()['true'].reshape(-1)
        mask = ground_truth != -100
        ground_truth = ground_truth[mask]
        prediction = prediction[mask]
        metric = task2metric[task](ground_truth, prediction)
        print(f"{task} : {metric[metrics[i]]}")
        weight = task2weight[task]
        weighted_score_sum += metric[metrics[i]] * weight

    # --- Final weighted score ---
    print(f"Overall Weighted Score: {weighted_score_sum}")
    print(f"Max Possible Score: 6")