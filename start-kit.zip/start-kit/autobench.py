# -*- coding: utf-8 -*-
# file: autobench.py
# time: 13:26 18/04/04/2025
# author: YANG, HENG <hy345@exeter.ac.uk> (杨恒)
# github: https://github.com/yangheng95
# huggingface: https://huggingface.co/yangheng
# google scholar: https://scholar.google.com/citations?user=NPq5a_0AAAAJ&hl=en
# Copyright (C) 2019-2025. All Rights Reserved.
import random

from omnigenome import AutoBench
if __name__ == "__main__":
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("--gfm", type=str, default="genomic_foundation_models/OmniGenome-52M-1000")
    parser.add_argument("--benchmark", type=str, default="RGB")
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--patience", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--seeds", type=int, default=random.randint(0, 1000))
    parser.add_argument("--deepspeed", default="ds_config.json")
    args = parser.parse_args()

    gfms = [
        "yangheng/OmniGenome-v1.5",
    ]
    benchmark = "OGB"
    batch_size = 8
    epochs = 10
    patience = 5
    # max_examples = 100
    max_examples = None
    seeds = [random.randint(0, 1000) for _ in range(1)]
    for gfm in gfms:
        if 'multimolecule' in gfm:
            from multimolecule import RnaTokenizer, AutoModelForTokenPrediction
            tokenizer = RnaTokenizer.from_pretrained(gfm)
            gfm = AutoModelForTokenPrediction.from_pretrained(gfm, trust_remote_code=True).base_model
        else:
            tokenizer = None
        bench = AutoBench(
            benchmark=benchmark,
            model_name_or_path=gfm,
            tokenizer=tokenizer,
            overwrite=True,
            # trainer='accelerate',
            trainer='native',
            autocast='fp16'
        )
        bench.run(
            # The following parameters are optional and will override the default values
            batch_size=batch_size,
            gradient_accumulation_steps=1,
            max_examples=max_examples,
            patience=patience,
            seeds=seeds,
            epochs=epochs,
        )


